import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Valorar vivienda en Alcorcón y zona sur | BKC Home',
  description:
    'Calcula una valoración orientativa y gratuita de tu vivienda. Especialistas en Alcorcón, Móstoles, Fuenlabrada, Leganés, Villaviciosa de Odón y Boadilla del Monte.',
  alternates: { canonical: '/valora-tu-vivienda' },
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
