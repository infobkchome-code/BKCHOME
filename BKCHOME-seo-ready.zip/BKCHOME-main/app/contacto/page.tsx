import type { Metadata } from 'next';

const PHONE = '+34 617 476 695';
const WHATSAPP = 'https://wa.me/34617476695';
const EMAIL = 'info@bkchome.es';
const ADDRESS = 'Calle de la Canaleja 3, 28921 Alcorcón, Madrid';

export const metadata: Metadata = {
  title: 'Contacto | BKC Home Inmobiliaria en Alcorcón',
  description:
    'Contacta con BKC Home. Inmobiliaria en Alcorcón y zona sur: venta, compra y valoración. Atención por teléfono, WhatsApp o email.',
  alternates: { canonical: '/contacto' },
};

export default function ContactoPage() {
  const mapsUrl = `https://www.google.com/maps?q=${encodeURIComponent(ADDRESS)}`;

  const localBusinessSchema = {
    '@context': 'https://schema.org',
    '@type': 'RealEstateAgent',
    name: 'BKC Home',
    url: 'https://bkchome.es',
    telephone: PHONE,
    email: EMAIL,
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Calle de la Canaleja 3',
      addressLocality: 'Alcorcón',
      addressRegion: 'Madrid',
      postalCode: '28921',
      addressCountry: 'ES',
    },
    areaServed: [
      'Alcorcón',
      'Móstoles',
      'Fuenlabrada',
      'Leganés',
      'Villaviciosa de Odón',
      'Boadilla del Monte',
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: PHONE,
      contactType: 'customer service',
      areaServed: 'ES',
      availableLanguage: ['es'],
    },
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-12 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />

      <header className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Contacto</h1>
        <p className="text-slate-600 max-w-2xl">
          ¿Quieres vender, comprar o pedir una valoración? Escríbenos y te respondemos con los próximos pasos.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div>
            <p className="text-xs font-semibold text-slate-700">Teléfono</p>
            <a className="text-sm text-emerald-700 hover:underline" href={`tel:${PHONE.replace(/\s/g, '')}`}> 
              {PHONE}
            </a>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-700">WhatsApp</p>
            <a className="text-sm text-emerald-700 hover:underline" href={WHATSAPP} target="_blank" rel="noopener noreferrer">
              Abrir WhatsApp
            </a>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-700">Email</p>
            <a className="text-sm text-emerald-700 hover:underline" href={`mailto:${EMAIL}`}>{EMAIL}</a>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-700">Oficina</p>
            <a className="text-sm text-slate-700 hover:underline" href={mapsUrl} target="_blank" rel="noopener noreferrer">
              {ADDRESS}
            </a>
          </div>

          <div className="pt-2">
            <p className="text-xs text-slate-500">
              Zonas principales: Alcorcón, Móstoles, Fuenlabrada, Leganés, Villaviciosa de Odón y Boadilla del Monte.
            </p>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs font-semibold text-slate-700">Mapa</p>
          <div className="mt-3 aspect-[4/3] w-full overflow-hidden rounded-xl border border-slate-200">
            <iframe
              title="Mapa BKC Home"
              src={`https://www.google.com/maps?output=embed&q=${encodeURIComponent(ADDRESS)}`}
              className="w-full h-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Si lo prefieres, puedes abrir el mapa en una pestaña nueva.
          </p>
          <a className="mt-2 inline-flex text-sm text-emerald-700 hover:underline" href={mapsUrl} target="_blank" rel="noopener noreferrer">
            Abrir en Google Maps
          </a>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">Enlaces rápidos</h2>
        <div className="mt-3 flex flex-wrap gap-2 text-sm">
          <a className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 hover:bg-slate-100" href="/vender">Vender</a>
          <a className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 hover:bg-slate-100" href="/comprar">Comprar</a>
          <a className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 hover:bg-slate-100" href="/valora-tu-vivienda">Valorar vivienda</a>
          <a className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 hover:bg-slate-100" href="/zonas">Zonas</a>
        </div>
      </section>
    </div>
  );
}
