import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Quiénes somos | BKC Home',
  description:
    'BKC Home es una inmobiliaria en Alcorcón especializada en la zona sur y noroeste de Madrid. Venta, compra y acompañamiento completo hasta notaría.',
  alternates: { canonical: '/quienes-somos' },
};

export default function QuienesSomosPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-6">
      <h1 className="text-3xl md:text-4xl font-semibold text-slate-900">Quiénes somos</h1>

      <div className="rounded-3xl border border-slate-200 bg-white p-6 space-y-4">
        <p className="text-slate-700">
          En BKC Home trabajamos con un enfoque simple: claridad, datos y acompañamiento real.
          Nuestro objetivo es que vendas o compres con seguridad, con una estrategia clara y sin
          sorpresas en arras o notaría.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl border border-slate-200 p-4">
            <p className="text-sm font-semibold text-slate-900">Estrategia de precio</p>
            <p className="text-xs text-slate-600 mt-1">
              Análisis del mercado, comparables y plan de acción realista.
            </p>
          </div>
          <div className="rounded-2xl border border-slate-200 p-4">
            <p className="text-sm font-semibold text-slate-900">Marketing + filtrado</p>
            <p className="text-xs text-slate-600 mt-1">
              Presentación profesional y visitas con compradores cualificados.
            </p>
          </div>
          <div className="rounded-2xl border border-slate-200 p-4">
            <p className="text-sm font-semibold text-slate-900">Operación completa</p>
            <p className="text-xs text-slate-600 mt-1">
              Coordinación de documentación, arras, tiempos y notaría.
            </p>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4">
          <p className="text-sm font-semibold text-slate-900">Zonas principales</p>
          <p className="text-xs text-slate-600 mt-1">
            Trabajamos sobre todo en Alcorcón, Villaviciosa de Odón, Boadilla del Monte, Móstoles,
            Fuenlabrada y Leganés.
          </p>
          <a href="/zonas" className="inline-block mt-2 text-sm text-emerald-700 font-semibold hover:underline">
            Ver zonas de trabajo
          </a>
        </div>

        <div className="flex flex-wrap gap-3 pt-1">
          <a
            href="/contacto"
            className="px-4 py-2.5 rounded-2xl bg-emerald-700 text-white text-sm font-semibold hover:bg-emerald-800"
          >
            Contactar
          </a>
          <a
            href="/vender"
            className="px-4 py-2.5 rounded-2xl border border-slate-200 text-sm font-semibold hover:bg-white"
          >
            Quiero vender
          </a>
          <a
            href="/valora-tu-vivienda"
            className="px-4 py-2.5 rounded-2xl border border-slate-200 text-sm font-semibold hover:bg-white"
          >
            Valorar vivienda
          </a>
        </div>
      </div>
    </div>
  );
}
