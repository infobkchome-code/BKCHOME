import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Comprar vivienda en Alcorcón y zona sur | BKC Home',
  description:
    'Te ayudamos a comprar con seguridad: búsqueda, visitas, negociación y acompañamiento hasta notaría. Alcorcón, Móstoles, Fuenlabrada, Leganés, Villaviciosa de Odón y Boadilla del Monte.',
  alternates: { canonical: '/comprar' },
};

const FAQ = [
  {
    q: '¿Cobráis honorarios al comprador?',
    a: 'Depende del inmueble y del tipo de servicio. Cuando exista un servicio al comprador, lo explicamos por escrito antes de avanzar para evitar sorpresas.',
  },
  {
    q: '¿Me ayudáis con la hipoteca?',
    a: 'Sí. Podemos orientarte con opciones de financiación y documentación para mejorar tu perfil ante banco.',
  },
  {
    q: '¿Qué gastos debo tener en cuenta al comprar?',
    a: 'Impuestos (ITP/AJD según el caso), notaría, registro, gestoría y posibles gastos de financiación. Te ayudamos a estimarlos antes de decidir.',
  },
  {
    q: '¿Podéis buscar inmuebles aunque no estén en portales?',
    a: 'Sí. Además de portales, trabajamos red de contactos y búsqueda activa por zona cuando tiene sentido.',
  },
] as const;

export default function ComprarPage() {
  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: FAQ.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-12 space-y-10">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />

      <header className="space-y-3">
        <h1 className="text-3xl font-bold text-slate-900">
          Comprar vivienda en Alcorcón y alrededores
        </h1>
        <p className="text-slate-600 max-w-2xl">
          Te acompañamos en todo el proceso para comprar con tranquilidad: selección, visitas,
          negociación, revisión documental y cierre en notaría.
        </p>
        <div className="flex flex-wrap gap-2 text-xs">
          <a href="/zonas/alcorcon" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Alcorcón</a>
          <a href="/zonas/mostoles" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Móstoles</a>
          <a href="/zonas/fuenlabrada" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Fuenlabrada</a>
          <a href="/zonas/leganes" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Leganés</a>
          <a href="/zonas/villaviciosa-de-odon" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Villaviciosa de Odón</a>
          <a href="/zonas/boadilla-del-monte" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Boadilla del Monte</a>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-700">Búsqueda</p>
          <p className="mt-2 text-sm text-slate-600">
            Definimos criterios y priorizamos visitas para no perder tiempo.
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-700">Negociación</p>
          <p className="mt-2 text-sm text-slate-600">
            Te ayudamos a negociar con datos y a proteger tu oferta.
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-700">Cierre</p>
          <p className="mt-2 text-sm text-slate-600">
            Coordinación de arras, financiación y notaría con checklist documental.
          </p>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">¿Quieres que te asesoremos?</h2>
        <p className="text-sm text-slate-600 mt-1">
          Escríbenos y te respondemos con los próximos pasos.
        </p>
        <div className="mt-4 flex flex-col sm:flex-row gap-2">
          <a
            href="/contacto"
            className="inline-flex items-center justify-center rounded-xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white hover:bg-emerald-700"
          >
            Hablar con BKC Home
          </a>
          <a
            href="/valora-tu-vivienda"
            className="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-900 hover:bg-slate-50"
          >
            Valorar una vivienda
          </a>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">Preguntas frecuentes</h2>
        <div className="mt-4 space-y-2">
          {FAQ.map((f) => (
            <details key={f.q} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
              <summary className="cursor-pointer text-sm font-medium text-slate-900">{f.q}</summary>
              <p className="mt-2 text-sm text-slate-600">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="text-sm text-slate-600">
        También trabajamos por zonas (con contenido específico para Google):{' '}
        <a className="text-emerald-700 hover:underline" href="/zonas">
          Ver zonas
        </a>
        .
      </section>
    </div>
  );
}
