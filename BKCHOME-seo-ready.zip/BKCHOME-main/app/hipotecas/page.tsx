import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Hipotecas en Alcorcón y zona sur | BKC Home',
  description:
    'Te acompañamos en la financiación de tu compra: orientación, documentación y coordinación con entidades. Alcorcón, Móstoles, Fuenlabrada, Leganés, Villaviciosa de Odón y Boadilla del Monte.',
  alternates: { canonical: '/hipotecas' },
};

export default function HipotecasPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-6">
      <h1 className="text-3xl md:text-4xl font-semibold text-slate-900">Hipotecas</h1>

      <div className="rounded-3xl border border-slate-200 bg-white p-6 space-y-4">
        <p className="text-slate-700">
          Si estás comprando, la financiación suele ser el punto clave. Te ayudamos a preparar la operación
          para que llegue sólida a la firma: documentación, tiempos, coordinación y criterios de viabilidad.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="rounded-2xl border border-slate-200 p-4">
            <p className="text-sm font-semibold text-slate-900">Primera revisión</p>
            <p className="text-xs text-slate-600 mt-1">Ingresos, endeudamiento y documentación necesaria.</p>
          </div>
          <div className="rounded-2xl border border-slate-200 p-4">
            <p className="text-sm font-semibold text-slate-900">Acompañamiento</p>
            <p className="text-xs text-slate-600 mt-1">Seguimiento hasta notaría y coordinación de hitos.</p>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4">
          <p className="text-sm font-semibold text-slate-900">Área cliente y seguimiento</p>
          <p className="text-xs text-slate-600 mt-1">
            Si ya estás en proceso con nosotros, tu gestor te habrá dado un enlace de seguimiento.
          </p>
          <a
            href="https://hipotecasbkc.es"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block mt-2 text-sm text-emerald-700 font-semibold hover:underline"
          >
            Ir a Hipotecas BKC
          </a>
        </div>

        <div className="flex flex-wrap gap-3">
          <a
            href="/contacto"
            className="px-4 py-2.5 rounded-2xl bg-emerald-700 text-white text-sm font-semibold hover:bg-emerald-800"
          >
            Contactar
          </a>
          <a
            href="/comprar"
            className="px-4 py-2.5 rounded-2xl border border-slate-200 text-sm font-semibold hover:bg-white"
          >
            Estoy buscando vivienda
          </a>
        </div>
      </div>
    </div>
  );
}
