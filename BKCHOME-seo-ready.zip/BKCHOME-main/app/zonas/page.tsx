import type { Metadata } from 'next';
import Link from 'next/link';

const ZONAS = [
  { slug: 'alcorcon', name: 'Alcorcón' },
  { slug: 'mostoles', name: 'Móstoles' },
  { slug: 'fuenlabrada', name: 'Fuenlabrada' },
  { slug: 'leganes', name: 'Leganés' },
  { slug: 'villaviciosa-de-odon', name: 'Villaviciosa de Odón' },
  { slug: 'boadilla-del-monte', name: 'Boadilla del Monte' },
] as const;

export const metadata: Metadata = {
  title: 'Zonas | BKC Home',
  description:
    'Trabajamos principalmente en Alcorcón, Móstoles, Fuenlabrada, Leganés, Villaviciosa de Odón y Boadilla del Monte. Consulta nuestra guía por zona.',
  alternates: { canonical: '/zonas' },
};

export default function ZonasPage() {
  return (
    <main className="max-w-5xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <header className="space-y-2">
        <p className="text-xs uppercase tracking-[0.22em] text-slate-500">
          Zonas de trabajo
        </p>
        <h1 className="text-2xl sm:text-3xl font-semibold text-slate-900">
          Inmobiliaria en Alcorcón y alrededores
        </h1>
        <p className="text-sm text-slate-600 max-w-2xl">
          Si buscas vender o comprar, aquí tienes páginas específicas por zona con
          información práctica, enfoque local y accesos directos a nuestros
          servicios.
        </p>
      </header>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {ZONAS.map((z) => (
          <Link
            key={z.slug}
            href={`/zonas/${z.slug}`}
            className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:bg-slate-50 transition"
          >
            <h2 className="text-base font-semibold text-slate-900">
              {z.name}
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Guía de la zona, puntos clave para vender y comprar y FAQs.
            </p>
            <p className="text-xs text-emerald-700 mt-3 font-medium">
              Ver página →
            </p>
          </Link>
        ))}
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
        <h2 className="text-sm font-semibold text-slate-900">
          ¿Qué hacemos exactamente?
        </h2>
        <div className="grid gap-3 md:grid-cols-3">
          <Link
            href="/vender"
            className="rounded-xl border border-slate-200 p-4 hover:bg-slate-50"
          >
            <p className="text-sm font-semibold text-slate-900">Vender</p>
            <p className="text-xs text-slate-600 mt-1">
              Estrategia de precio, marketing, visitas y negociación.
            </p>
          </Link>
          <Link
            href="/comprar"
            className="rounded-xl border border-slate-200 p-4 hover:bg-slate-50"
          >
            <p className="text-sm font-semibold text-slate-900">Comprar</p>
            <p className="text-xs text-slate-600 mt-1">
              Búsqueda, filtros, ofertas y acompañamiento hasta notaría.
            </p>
          </Link>
          <Link
            href="/valora-tu-vivienda"
            className="rounded-xl border border-slate-200 p-4 hover:bg-slate-50"
          >
            <p className="text-sm font-semibold text-slate-900">Valoración</p>
            <p className="text-xs text-slate-600 mt-1">
              Estimación orientativa y planificación de venta.
            </p>
          </Link>
        </div>
      </section>
    </main>
  );
}
