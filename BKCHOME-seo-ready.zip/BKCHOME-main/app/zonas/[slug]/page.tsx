import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';

type Zona = {
  slug: string;
  name: string;
  title: string;
  description: string;
  h1: string;
  intro: string;
  faqs: { q: string; a: string }[];
};

const ZONAS: Zona[] = [
  {
    slug: 'alcorcon',
    name: 'Alcorcón',
    title: 'Inmobiliaria en Alcorcón | BKC Home',
    description:
      'Servicio inmobiliario en Alcorcón: vender vivienda, comprar con seguridad y acompañamiento en financiación. Oficina en Calle de la Canaleja 3.',
    h1: 'Inmobiliaria en Alcorcón',
    intro:
      'Trabajamos el mercado de Alcorcón con enfoque local: precio realista, marketing que atrae compradores y acompañamiento hasta notaría. Si necesitas vender o comprar, aquí tienes la guía práctica y los pasos clave.',
    faqs: [
      {
        q: '¿Cuánto tarda en venderse una vivienda en Alcorcón?',
        a: 'Depende del precio, la demanda y el estado del inmueble. En general, una estrategia de precio correcta + marketing (fotos, anuncio, filtros y visitas) reduce tiempos y evita rebajas innecesarias.',
      },
      {
        q: '¿Cómo fijáis el precio de salida?',
        a: 'Combinamos testigos reales, demanda actual, características del inmueble y márgenes de negociación. La idea es salir “bien colocado” para recibir visitas desde el primer momento.',
      },
      {
        q: '¿Me ayudáis con la hipoteca si soy comprador?',
        a: 'Sí. Podemos orientar la operación para que la compra sea viable y segura, revisando documentación y pasos antes de comprometerte con arras.',
      },
      {
        q: '¿Qué documentación necesito para vender?',
        a: 'Como base: nota simple, DNI, recibos de IBI, certificado de comunidad (si aplica), certificados energéticos y, según caso, documentación adicional. Te guiamos para tenerlo listo a tiempo.',
      },
      {
        q: '¿En qué zonas de Alcorcón trabajáis?',
        a: 'Trabajamos Alcorcón en general. Si nos dices tu calle o urbanización, te damos una orientación más afinada de precio y demanda.',
      },
    ],
  },
  {
    slug: 'mostoles',
    name: 'Móstoles',
    title: 'Inmobiliaria en Móstoles | BKC Home',
    description:
      'Servicio inmobiliario en Móstoles: vender y comprar vivienda con asesoramiento completo y acompañamiento hasta notaría.',
    h1: 'Inmobiliaria en Móstoles',
    intro:
      'En Móstoles, una venta rápida y con buen precio depende de salir al mercado con una estrategia clara: precio, anuncio, visitas y negociación. Te ayudamos a ordenar todo el proceso y a evitar errores típicos.',
    faqs: [
      {
        q: '¿Qué es lo más importante para vender en Móstoles?',
        a: 'La combinación de precio + presentación. Un inmueble bien anunciado y con precio realista consigue visitas, ofertas y reduce regateos agresivos.',
      },
      {
        q: '¿Puedo vender aunque todavía tenga hipoteca?',
        a: 'Sí. Se puede vender y cancelar la hipoteca en la firma, coordinando notaría y banco. Es algo habitual.',
      },
      {
        q: '¿Cómo gestionáis las visitas?',
        a: 'Filtramos interesados, organizamos horarios y registramos feedback. Así puedes tomar decisiones con datos, no con sensaciones.',
      },
      {
        q: '¿Ayudáis con arras y documentación?',
        a: 'Sí. Te indicamos qué pedir, revisamos lo esencial y coordinamos para llegar a notaría sin sorpresas.',
      },
      {
        q: '¿Trabajáis también con compradores en Móstoles?',
        a: 'Sí. Acompañamos al comprador en todo el proceso y, si procede, orientamos la financiación.',
      },
    ],
  },
  {
    slug: 'fuenlabrada',
    name: 'Fuenlabrada',
    title: 'Inmobiliaria en Fuenlabrada | BKC Home',
    description:
      'Servicio inmobiliario en Fuenlabrada: venta de vivienda, compra con acompañamiento y asesoramiento de financiación.',
    h1: 'Inmobiliaria en Fuenlabrada',
    intro:
      'Fuenlabrada tiene un mercado dinámico y muy sensible al precio. Nuestro enfoque es claro: preparación del inmueble, salida al mercado con buen anuncio y seguimiento de visitas para negociar con fuerza.',
    faqs: [
      {
        q: '¿Recomendáis hacer pequeñas mejoras antes de vender?',
        a: 'Sí, si son mejoras de alta rentabilidad (pintura, orden, iluminación, limpieza). Te decimos qué merece la pena y qué no.',
      },
      {
        q: '¿Cómo evitamos perder tiempo con curiosos?',
        a: 'Con filtros: presupuesto, necesidad real y timing. Menos visitas, pero mejores.',
      },
      {
        q: '¿Qué pasa si recibo varias ofertas?',
        a: 'Te ayudamos a comparar condiciones (financiación, plazos, arras) y a elegir la más segura, no solo la más alta.',
      },
      {
        q: '¿Puedo comprar y vender a la vez?',
        a: 'Sí. Se planifica con tiempos y financiación. Lo importante es ordenar calendario y documentación.',
      },
      {
        q: '¿Trabajáis con inversores?',
        a: 'Según el inmueble, sí. Pero siempre priorizamos la mejor salida para el propietario.',
      },
    ],
  },
  {
    slug: 'leganes',
    name: 'Leganés',
    title: 'Inmobiliaria en Leganés | BKC Home',
    description:
      'Servicio inmobiliario en Leganés: vender y comprar vivienda con estrategia de precio, marketing y acompañamiento completo.',
    h1: 'Inmobiliaria en Leganés',
    intro:
      'Para vender en Leganés con buenas condiciones, hay que preparar la operación desde el minuto 1: precio, anuncio, visitas y documentación. Nosotros lo ordenamos contigo y lo ejecutamos.',
    faqs: [
      {
        q: '¿Qué documentación debo tener lista antes de publicar?',
        a: 'Lo esencial: nota simple, recibos de IBI, datos de comunidad si aplica y certificados necesarios. Te damos una lista exacta según tu caso.',
      },
      {
        q: '¿Cómo mejoro el anuncio para atraer compradores?',
        a: 'Fotos correctas, texto claro, puntos fuertes (luz, distribución, ubicación) y un precio alineado con el mercado.',
      },
      {
        q: '¿Cuándo conviene aceptar una oferta?',
        a: 'Cuando encaja en precio y, sobre todo, en seguridad (financiación y plazos). Una oferta “segura” suele ser mejor que una alta pero débil.',
      },
      {
        q: '¿Acompañáis al comprador hasta notaría?',
        a: 'Sí. Coordinamos y damos soporte para que la operación llegue a firma sin sobresaltos.',
      },
      {
        q: '¿Podéis orientar la financiación al comprador?',
        a: 'Sí, especialmente si hay dudas de viabilidad antes de arras.',
      },
    ],
  },
  {
    slug: 'villaviciosa-de-odon',
    name: 'Villaviciosa de Odón',
    title: 'Inmobiliaria en Villaviciosa de Odón | BKC Home',
    description:
      'Servicio inmobiliario en Villaviciosa de Odón: venta y compra de vivienda con enfoque en chalets y mercado residencial.',
    h1: 'Inmobiliaria en Villaviciosa de Odón',
    intro:
      'Villaviciosa de Odón suele requerir una estrategia más “premium”: buen reportaje, filtrado de visitas y negociación cuidada. Te acompañamos en la preparación, publicación y cierre.',
    faqs: [
      {
        q: '¿Qué diferencia una venta “premium”?',
        a: 'Presentación (fotos, orden, narrativa), filtros y una negociación basada en condiciones, no solo en precio.',
      },
      {
        q: '¿Cómo se gestiona la privacidad en visitas?',
        a: 'Con agendas cerradas, validación previa de interesados y acompañamiento en todo momento.',
      },
      {
        q: '¿Conviene pedir arras más altas?',
        a: 'Depende del perfil comprador y de la financiación. Lo importante es asegurar compromiso real y plazos realistas.',
      },
      {
        q: '¿Ayudáis al comprador con financiación?',
        a: 'Sí, si es necesario para asegurar la viabilidad antes de comprometerse.',
      },
      {
        q: '¿Trabajáis también con propiedades de inversión?',
        a: 'Sí, cuando encaja, pero cuidando que el propietario tenga la mejor salida posible.',
      },
    ],
  },
  {
    slug: 'boadilla-del-monte',
    name: 'Boadilla del Monte',
    title: 'Inmobiliaria en Boadilla del Monte | BKC Home',
    description:
      'Servicio inmobiliario en Boadilla del Monte: venta y compra de vivienda con estrategia de marketing y negociación.',
    h1: 'Inmobiliaria en Boadilla del Monte',
    intro:
      'En Boadilla del Monte, la clave es una estrategia de salida que proteja el valor: reportaje, mensaje claro, filtrado y negociación. Nos enfocamos en operaciones seguras y con buena comunicación.',
    faqs: [
      {
        q: '¿Cómo preparo mi casa para vender?',
        a: 'Orden, limpieza, iluminación y pequeñas mejoras si aportan. Te decimos qué hacer para mejorar visitas sin gastar de más.',
      },
      {
        q: '¿Cómo valoráis un chalet?',
        a: 'Por testigos reales, características (parcela, distribución, estado), demanda y comparables recientes. Luego ajustamos estrategia de salida.',
      },
      {
        q: '¿Cómo evitamos ofertas muy a la baja?',
        a: 'Precio bien alineado + anuncio sólido + filtros. Cuando el mercado percibe “valor”, el regateo agresivo baja.',
      },
      {
        q: '¿Puedo comprar con hipoteca al 100%?',
        a: 'Depende del perfil y del banco. Te orientamos sobre viabilidad y pasos antes de arras.',
      },
      {
        q: '¿Gestionáis todo hasta notaría?',
        a: 'Sí. Coordinamos documentación, tiempos y comunicación con las partes.',
      },
    ],
  },
];

function getZona(slug: string): Zona | undefined {
  return ZONAS.find((z) => z.slug === slug);
}

export async function generateStaticParams() {
  return ZONAS.map((z) => ({ slug: z.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const zona = getZona(params.slug);
  if (!zona) return {};
  return {
    title: zona.title,
    description: zona.description,
    alternates: { canonical: `/zonas/${zona.slug}` },
  };
}

export default function ZonaPage({ params }: { params: { slug: string } }) {
  const zona = getZona(params.slug);
  if (!zona) return notFound();

  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: zona.faqs.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer',
        text: f.a,
      },
    })),
  };

  return (
    <main className="max-w-5xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <header className="space-y-2">
        <p className="text-xs uppercase tracking-[0.22em] text-slate-500">
          Zona
        </p>
        <h1 className="text-2xl sm:text-3xl font-semibold text-slate-900">
          {zona.h1}
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl">{zona.intro}</p>
      </header>

      <section className="grid gap-3 md:grid-cols-3">
        <Link
          href="/vender"
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:bg-slate-50"
        >
          <p className="text-sm font-semibold text-slate-900">Vender en {zona.name}</p>
          <p className="text-xs text-slate-600 mt-1">
            Estrategia de precio, anuncio, visitas y negociación.
          </p>
        </Link>
        <Link
          href="/comprar"
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:bg-slate-50"
        >
          <p className="text-sm font-semibold text-slate-900">Comprar en {zona.name}</p>
          <p className="text-xs text-slate-600 mt-1">
            Búsqueda, ofertas y acompañamiento hasta notaría.
          </p>
        </Link>
        <Link
          href="/valora-tu-vivienda"
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:bg-slate-50"
        >
          <p className="text-sm font-semibold text-slate-900">Valorar vivienda</p>
          <p className="text-xs text-slate-600 mt-1">
            Estimación orientativa para decidir con datos.
          </p>
        </Link>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <h2 className="text-base font-semibold text-slate-900">Preguntas frecuentes</h2>
        <div className="space-y-3">
          {zona.faqs.map((f) => (
            <details
              key={f.q}
              className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
            >
              <summary className="cursor-pointer text-sm font-medium text-slate-900">
                {f.q}
              </summary>
              <p className="text-sm text-slate-700 mt-2">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-emerald-200 bg-emerald-50 p-6 shadow-sm space-y-3">
        <h2 className="text-base font-semibold text-emerald-900">¿Hablamos?</h2>
        <p className="text-sm text-emerald-900/80">
          Cuéntanos tu caso y te damos una orientación clara (sin rodeos) para vender o comprar en {zona.name}.
        </p>
        <div className="flex flex-wrap gap-2">
          <Link
            href="/contacto"
            className="inline-flex items-center rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
          >
            Contactar
          </Link>
          <Link
            href="/valora-tu-vivienda"
            className="inline-flex items-center rounded-xl border border-emerald-300 bg-white px-4 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-100"
          >
            Valorar mi vivienda
          </Link>
        </div>
      </section>
    </main>
  );
}
