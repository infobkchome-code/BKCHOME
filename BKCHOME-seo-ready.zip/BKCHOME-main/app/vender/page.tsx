import type { Metadata } from 'next';
import LeadForm from '../components/LeadForm';

export const metadata: Metadata = {
  title: 'Vender casa en Alcorcón y zona sur | BKC Home',
  description:
    'Vende tu vivienda con estrategia, marketing y seguridad jurídica. Especialistas en Alcorcón, Móstoles, Fuenlabrada, Leganés, Villaviciosa de Odón y Boadilla del Monte.',
  alternates: { canonical: '/vender' },
};

const FAQ = [
  {
    q: '¿Cuánto tarda normalmente la venta de una vivienda?',
    a: 'Depende del precio, la zona y la demanda. La clave es salir bien al mercado desde el primer día: precio, reportaje, anuncio y filtro de visitas.',
  },
  {
    q: '¿Cómo se calcula el precio de salida?',
    a: 'Combinamos comparables reales, estado del inmueble, orientación y demanda. Si quieres, puedes pedir una valoración orientativa gratuita desde la web.',
  },
  {
    q: '¿Qué documentación necesito para empezar?',
    a: 'Como mínimo: DNI, nota simple o escritura, recibos de IBI y comunidad (si aplica), y certificado energético. Te guiamos paso a paso.',
  },
  {
    q: '¿Gestionáis compradores con hipoteca?',
    a: 'Sí. Podemos ayudar al comprador con la financiación, lo que acelera el proceso y reduce incertidumbre en la operación.',
  },
] as const;

export default function VenderPage() {
  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: FAQ.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-12 space-y-10">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <header className="space-y-3">
        <h1 className="text-3xl font-bold text-slate-900">
          Vender tu casa en Alcorcón y zona sur
        </h1>
        <p className="text-slate-600 max-w-2xl">
          Te ayudamos a vender con un plan claro: valoración, estrategia de precio,
          reportaje, publicación y acompañamiento legal hasta notaría.
        </p>
        <div className="flex flex-wrap gap-2 text-xs">
          <a href="/zonas/alcorcon" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Alcorcón</a>
          <a href="/zonas/mostoles" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Móstoles</a>
          <a href="/zonas/fuenlabrada" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Fuenlabrada</a>
          <a href="/zonas/leganes" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Leganés</a>
          <a href="/zonas/villaviciosa-de-odon" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Villaviciosa de Odón</a>
          <a href="/zonas/boadilla-del-monte" className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 hover:bg-slate-50">Boadilla del Monte</a>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-700">1) Valoración</p>
          <p className="mt-2 text-sm text-slate-600">Análisis de mercado y rango de precio realista para vender sin regalar.</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-700">2) Marketing</p>
          <p className="mt-2 text-sm text-slate-600">Reportaje, anuncio optimizado y plan de difusión para atraer demanda cualificada.</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-700">3) Cierre</p>
          <p className="mt-2 text-sm text-slate-600">Filtro de visitas, negociación y acompañamiento documental hasta notaría.</p>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">Pide una valoración orientativa</h2>
        <p className="text-sm text-slate-600 mt-1">
          Cuéntanos los datos básicos y te contactamos.
        </p>
        <div className="mt-4">
          <LeadForm />
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">Preguntas frecuentes</h2>
        <div className="mt-4 space-y-2">
          {FAQ.map((f) => (
            <details key={f.q} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
              <summary className="cursor-pointer text-sm font-medium text-slate-900">{f.q}</summary>
              <p className="mt-2 text-sm text-slate-600">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="text-sm text-slate-600">
        ¿Quieres ver cómo trabajamos por zonas?{' '}
        <a className="text-emerald-700 hover:underline" href="/zonas">
          Ver zonas
        </a>
        .
      </section>
    </div>
  );
}
