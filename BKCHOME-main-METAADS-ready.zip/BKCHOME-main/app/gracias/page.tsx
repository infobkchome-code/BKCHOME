export const metadata = {
  title: "Gracias — Hemos recibido tu solicitud",
  description:
    "Hemos recibido tu solicitud de valoración. Te contactaremos lo antes posible. Si quieres acelerar, escríbenos por WhatsApp.",
};

const PHONE = "+34617476695";
const WHATSAPP = "https://wa.me/34617476695";

export default function GraciasPage() {
  return (
    <main className="min-h-screen bg-slate-50">
      <section className="border-b border-slate-200 bg-white">
        <div className="max-w-3xl mx-auto px-4 py-12 md:py-16">
          <p className="text-xs font-medium tracking-[0.25em] text-slate-500 uppercase">
            BKC Home · Alcorcón y zona sur
          </p>

          <h1 className="mt-3 text-3xl md:text-5xl font-semibold leading-tight text-slate-900">
            ¡Gracias! Ya lo tenemos.
          </h1>

          <p className="mt-4 text-slate-700 text-base md:text-lg">
            Hemos recibido tus datos para la valoración. Te contactamos lo antes posible.
            Si quieres ir más rápido, escríbenos por WhatsApp y te atendemos en el momento.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <a
              href={WHATSAPP}
              className="inline-flex items-center justify-center rounded-2xl bg-emerald-700 px-5 py-3 text-white text-sm font-semibold hover:bg-emerald-800"
            >
              Abrir WhatsApp
            </a>
            <a
              href={`tel:${PHONE}`}
              className="inline-flex items-center justify-center rounded-2xl border border-slate-200 bg-white px-5 py-3 text-slate-900 text-sm font-semibold hover:bg-slate-50"
            >
              Llamar ahora
            </a>

            <a
              href="/"
              className="inline-flex items-center justify-center rounded-2xl border border-slate-200 bg-white px-5 py-3 text-slate-900 text-sm font-semibold hover:bg-slate-50"
            >
              Volver a la web
            </a>
          </div>

          <div className="mt-10 rounded-3xl border border-slate-200 bg-slate-50 p-5">
            <div className="text-sm font-semibold text-slate-900">Qué pasa ahora</div>
            <ul className="mt-3 space-y-2 text-sm text-slate-700">
              <li>✅ Confirmamos los datos (zona, m², características).</li>
              <li>✅ Contrastamos con comparables reales de tu zona.</li>
              <li>✅ Te damos un rango más preciso y (si quieres) un plan de venta.</li>
            </ul>
            <p className="mt-3 text-[11px] text-slate-500">
              *La valoración es orientativa y depende de estado, alturas, orientación,
              reforma, y demanda real en el momento.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
