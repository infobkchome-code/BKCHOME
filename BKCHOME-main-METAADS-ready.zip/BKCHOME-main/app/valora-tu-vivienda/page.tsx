import { redirect } from "next/navigation";

export const metadata = {
  title: "Valora tu vivienda — BKC Home",
  description:
    "Acceso al valorador de BKC Home. Calcula una estimación orientativa del valor de tu vivienda en 60 segundos.",
};

export default function ValoraTuViviendaRedirect({
  searchParams,
}: {
  searchParams?: Record<string, string | string[] | undefined>;
}) {
  const params = new URLSearchParams();

  if (searchParams) {
    for (const [k, v] of Object.entries(searchParams)) {
      if (typeof v === "string") params.set(k, v);
      else if (Array.isArray(v)) for (const item of v) params.append(k, item);
    }
  }

  const qs = params.toString();
  redirect(qs ? `/valorador?${qs}` : "/valorador");
}
