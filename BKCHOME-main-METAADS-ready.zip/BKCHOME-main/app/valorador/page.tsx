import ValoradorDetalle from "../components/ValoradorDetalle";

export const metadata = {
  title: "Valorador gratuito — ¿Cuánto vale tu vivienda?",
  description:
    "Calcula una estimación orientativa del valor de tu vivienda en 60 segundos. Alcorcón, Móstoles y zona sur de Madrid.",
};

export default function ValoradorPage() {
  return (
    <main className="min-h-screen bg-slate-50">
      <section className="border-b border-slate-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 py-10 md:py-14 grid gap-8 md:grid-cols-[1fr,1fr] md:items-start">
          <div className="max-w-xl space-y-4">
            <p className="text-xs font-medium tracking-[0.25em] text-slate-500 uppercase">
              Inmobiliaria · Alcorcón y zona sur
            </p>

            <h1 className="text-3xl md:text-5xl font-semibold leading-tight text-slate-900">
              Descubre cuánto vale tu casa
              <span className="block text-emerald-700 mt-1">en 60 segundos</span>
            </h1>

            <p className="text-base md:text-lg text-slate-700">
              Calcula una <span className="font-semibold">estimación orientativa</span>{" "}
              según datos de la zona. Si quieres, después te damos una valoración más precisa con comparables reales.
            </p>

            <ul className="text-sm text-slate-700 space-y-1">
              <li>✅ Sin compromiso</li>
              <li>✅ 1 minuto</li>
              <li>✅ Alcorcón · Móstoles · Zona sur</li>
            </ul>
          </div>

          <div>
            <ValoradorDetalle />
          </div>
        </div>
      </section>
    </main>
  );
}
