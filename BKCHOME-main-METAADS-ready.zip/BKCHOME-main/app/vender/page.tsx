import LeadForm from "../components/LeadForm";

export const metadata = {
  title: "Vender vivienda en Alcorcón y zona sur",
  description:
    "Vende tu vivienda con BKC Home: valoración, reportaje, marketing y acompañamiento hasta notaría. Zona sur de Madrid.",
};

export default function VenderPage() {
  return (
    <main className="min-h-screen bg-slate-50">
      <section className="border-b border-slate-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 py-10 md:py-14 grid gap-10 md:grid-cols-[1.2fr,0.8fr] md:items-start">
          <div className="max-w-2xl space-y-5">
            <p className="text-xs font-medium tracking-[0.25em] text-slate-500 uppercase">
              Inmobiliaria · Alcorcón y zona sur
            </p>

            <h1 className="text-3xl md:text-5xl font-semibold leading-tight text-slate-900">
              Vende tu vivienda
              <span className="block text-emerald-700 mt-1">con seguridad y sin sorpresas</span>
            </h1>

            <p className="text-base md:text-lg text-slate-700">
              Te ayudamos con la valoración, preparación, marketing y negociación para que vendas al mejor precio posible,
              con acompañamiento hasta notaría.
            </p>

            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
                <div className="text-sm font-semibold text-slate-900">Valoración realista</div>
                <p className="mt-1 text-sm text-slate-700">
                  Rango orientativo + revisión con comparables. Puedes empezar con el valorador y luego afinamos.
                </p>
                <a
                  href="/valorador"
                  className="mt-3 inline-flex text-sm font-semibold text-emerald-700 hover:underline"
                >
                  Ir al valorador →
                </a>
              </div>

              <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
                <div className="text-sm font-semibold text-slate-900">Marketing y visitas</div>
                <p className="mt-1 text-sm text-slate-700">
                  Reportaje, anuncio optimizado y filtro de interesados para evitar “turismo” de visitas.
                </p>
              </div>

              <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
                <div className="text-sm font-semibold text-slate-900">Negociación y documentación</div>
                <p className="mt-1 text-sm text-slate-700">
                  Te guiamos en arras, notas simples, cargas, y coordinación notarial hasta la firma.
                </p>
              </div>

              <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
                <div className="text-sm font-semibold text-slate-900">Zona sur (especialistas)</div>
                <p className="mt-1 text-sm text-slate-700">
                  Alcorcón, Móstoles y alrededores. Conocemos la demanda y el “precio real” de cierre.
                </p>
              </div>
            </div>
          </div>

          <div className="md:sticky md:top-6">
            <LeadForm
              source="vender"
              title="¿Quieres vender?"
              subtitle="Déjanos tus datos y te decimos cómo lo plantearíamos."
            />
          </div>
        </div>
      </section>
    </main>
  );
}
