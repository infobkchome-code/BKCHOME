# BKCHOME Web (Next.js)

## Variables de entorno

Configura estas variables en Vercel (Project → Settings → Environment Variables) y/o en `.env.local`.

- `NEXT_PUBLIC_SITE_URL` (ej: `https://bkchome.es`)
- `NEXT_PUBLIC_META_PIXEL_ID` (Pixel ID de Meta para tracking)
- `LEADS_WEBHOOK_URL` (opcional: webhook para recibir leads; si no, se loguean en consola)

## Rutas clave para campañas

- `/valorador` → landing del valorador (recomendada para Meta Ads)
- `/gracias` → página de confirmación tras enviar lead

